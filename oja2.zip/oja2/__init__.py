from .chunk import chunk_oja2
from .fused_recurrent import fused_recurrent_oja2

__all__ = [
    "chunk_oja2",
    "fused_recurrent_oja2"
]
